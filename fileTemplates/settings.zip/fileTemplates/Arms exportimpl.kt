package ${PACKAGE_NAME}.export


import com.flyjingfish.module_communication_annotation.ImplementClass

@ImplementClass(${MODULE_NAME}Export::class)
class ${MODULE_NAME}ExportImpl :${MODULE_NAME}Export {

}