package ${PACKAGE_NAME}.arouter


object ${MODULE_NAME}RouterHub {

    private const val GROUP: String = "/${MODULE_NAME}"

    const val public${MODULE_NAME}Service: String = "/${MODULE_NAME}/Service/I${MODULE_NAME}Service"
   // const val public${MODULE_NAME}TestActivity: String = "/${MODULE_NAME}/Activity/TestActivity"
   // const val public${MODULE_NAME}TestFragment: String = "/${MODULE_NAME}/Fragment/TestFragment"
}