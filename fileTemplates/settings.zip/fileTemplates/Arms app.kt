package ${PACKAGE_NAME}.app

import com.common.core.base.BaseApplication
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class ${MODULE_NAME}App : BaseApplication()