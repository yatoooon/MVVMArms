package ${PACKAGE_NAME}.arouter

import com.alibaba.android.arouter.facade.template.IProvider

interface I${MODULE_NAME}Service : IProvider {
    
}

